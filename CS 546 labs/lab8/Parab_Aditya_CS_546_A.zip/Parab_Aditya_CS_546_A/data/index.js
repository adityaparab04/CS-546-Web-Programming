const charactersData = require('./characters');

module.exports = {
    characters: charactersData
};